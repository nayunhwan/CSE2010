/*
 * (C) 2015 CSE2010 HW #2
 * 
 * DO NOT MODIFY THIS CLASS!
 */

public class Term {
	/*
	 * Public field is a bad idea. But, for the sake of simplicity .....
	 */
	public double 	coeff;	// coefficient
	public int 		expo;	// exponent
	
	public Term(double coeff, int expo) {
		this.coeff = coeff;
		this.expo = expo;
	}
}