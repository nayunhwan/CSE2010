/*
 * (C) 2015 CSE2010 HW #2
 * 
 * DO NOT MODIFY THIS CLASS!
 */

public class DuplicateException extends RuntimeException {

	/**
	 *  Ignore this
	 */
	private static final long serialVersionUID = 3906384695446803515L;

	public DuplicateException() { super(); }
	
	public DuplicateException(String e) { super(e);	}
}